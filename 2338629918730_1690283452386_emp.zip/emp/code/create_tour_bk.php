<!DOCTYPE html>
<html>
	<head>
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB7OEdDb4U8wdLbCVu4aUQhfyCnSzGY454&libraries=places"></script>
	</head>

	<?php include("includes/html_header.php"); ?>

	<body>
		<header>
            <div class="container">
                <a href="" class="logo">
                    <img src="./images/logo.png" alt="" />
                </a>
                <nav>
                    <a href="" class="nav-item">HOME</a>
                    <a href="" class="nav-item">MY PLANS</a>
                </nav>

                <div class="btns">
                    <!--Your are logged in as: <span><?php echo($_SESSION['name']);?></span>-->
                    <a href="./admin/logout.php"><button class="btn btn-success">Logout</button></a>
                </div>
            </div>
        </header>
		<div class="container">
			
			<div>
				<div class="tbl-tours">
					<div class="admin-heading">
						<h3>Create Tour Plan</h3>
					</div>
					<hr/>
					
					<div class="form-destinations">
					<form name="frm" id="frm" method="post" action="" class="form-horizontal" role="form" enctype="multipart/form-data">
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<label>Tour Title</label>
									<input type="text" class="form-control" id="title" placeholder="Title">
								</div>
								<div class="form-group">
									<label>Pickup Point</label>
									<input type="text" class="form-control" id="tb_pickup" placeholder="Pickup Point">
								</div>
								<div class="form-group">
									<label>Stay</label>
									<select class="form-control" id="tb_stay">
										<option>No</option>
										<option>Yes</option>
									</select>
								</div>

								<div class="form-group">
									<label>Destination</label>
									<input type="text" class="form-control" id="destination">
								</div>
								<div class="form-group">
									<label>Days</label>
									<select class="form-control" id="days">
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
										<option>6</option>
										<option>7</option>
										<option>8</option>
										<option>9</option>
										<option>10</option>
									</select>
								</div>
								<div class="form-group">
									<label>Meal</label>
									<select class="form-control" id="tb_food">
										<option>1</option>
										<option>2</option>
										<option>3</option>
									</select>
								</div>
								<div class="form-group">
									<label>Tour Description</label>
									<textarea class="form-control" id="description"></textarea>
								</div>
								<div class="form-group">
									<label>Image</label>
									<input type="file" class="form-control" id="tb_image">
								</div>
							</div>

							<div class="col-md-6">
								<div class="form-group">
									<label>Charges</label>
									<input type="number" class="form-control" id="charges" placeholder="Charges">
								</div>
								<div class="form-group">
									<label>Drop Point</label>
									<input type="text" class="form-control" id="tb_drop" placeholder="Drop Point">
								</div>
								<div class="form-group">
									<label>Accommodation</label>
									<select class="form-control" id="tb_accomodation">
										<option>No</option>
										<option>Yes</option>
									</select>
								</div>
								<div class="form-group">
									<label>Tour Date</label>
									<input type="date" class="form-control" id="date">
								</div>
								<div class="form-group">
									<label>Night</label>
									<select class="form-control" id="tp_night">
										<option>1</option>
										<option>2</option>
										<option>3</option>
										<option>4</option>
										<option>5</option>
										<option>6</option>
										<option>7</option>
										<option>8</option>
										<option>9</option>
										<option>10</option>
									</select>
								</div>
								<div class="form-group">
									<label>KM</label>
									<input type="text" class="form-control" id="tb_km" placeholder="KM">
								</div>
							</div>
						</div>
					</form>
					</div>
					<div id="btn-submit" class="btn btn-1 btn-success">Submit</div>

				</div>

			</div>

			<div id="message">
			</div>
		</div>

		
	</body>

	<script>
		var input = document.getElementById('destination');
    	var autocomplete = new google.maps.places.Autocomplete(input,{types: ['(cities)']});
		google.maps.event.addListener(autocomplete, 'place_changed', function(){
			var place = autocomplete.getPlace();
		});



		$(document).ready(function(){
			$('#btn-submit').click(function(){
				validateAndPost();
			})
		})



		function validateAndPost(){
			var title 		= $('#title').val();
			var destination	= $('#destination').val();
			var description = $('#description').val();
			var charges		= $('#charges').val();
			var date		= $('#date').val();
			var days 		= $('#days').val();
			var tp_night 	= $('#tp_night').val();
			var tb_pickup 	= $('#tb_pickup').val();
			var tb_drop 	= $('#tb_drop').val();
			var tb_stay 	= $('#tb_stay').val();
			var tb_accomodation = $('#tb_accomodation').val();
			var tb_km 		= $('#tb_km').val();
			var tb_food 	= $('#tb_food').val();
			var tb_image 	= $('#tb_image').val();

			if(title == '' || destination=='' || description=='' || charges=='' || date=='' || tb_image == ''){ // check username not empty
				alert('please fill all fields'); 
			}

			else{		
				$.ajax({
					url: './api/index.php?action=create_tour',
					type: 'post',
					data:	{
								title : title, 
								destination: destination,
								description: description,
								charges : charges, 
								date: date,
								days: days,
								tp_night: tp_night,
								tb_pickup: tb_pickup,
								tb_drop: tb_drop,
								tb_stay: tb_stay,
								tb_accomodation: tb_accomodation,
								tb_km: tb_km,
								tb_food: tb_food,
								tb_image: tb_image,
							},

					success: function(response){
						if(response.status==1){
							$('#message').html('<div class="alert alert-success" role="alert">Tour plan created successfully</div>');
							setTimeout(() => {
								window.location.href = "company_home.php";
							}, 2000);
						}
						else{
							$('#message').html('<div class="alert alert-danger" role="alert">'+response.message+'</div>');
							setTimeout(() => {
								$('#message').html('');
							}, 2000);
						}

					},

					 error: function(data) {
						successmessage = 'Error';
						$('#message').html(data);
					},

				});
			
				//$('#registraion_form')[0].reset();
			}

		}
    </script>

</html>