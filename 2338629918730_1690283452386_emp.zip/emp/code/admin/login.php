<!DOCTYPE html>
<html>

<?php
	include("./header.php");
?>

<body>
<div class="login-form-admin" >
	<section class="login-form">
		<h3 class="text-center" >Admin Login</h3>
		<form>
			<div class="input-group input-group-lg" >
				<span class="input-group-addon" id="sizing-addon1"><i class="fa fa-user" aria-hidden="true"></i></span>
				<input type="text" id="name" name="name" class="form-control" placeholder="Username" aria-describedby="sizing-addon1" required>
			</div>
			<br>
			<div class="input-group input-group-lg">
				<span class="input-group-addon" id="sizing-addon1"><i class="fa fa-key" aria-hidden="true"></i></span>
				<input type="password" id="pwd" name="pwd" class="form-control" placeholder="Password" aria-describedby="sizing-addon1" required>
			</div>
			<br>

			<input id="btn_submit" class="btn btn-success btn-block" value="Submit" name="submit">
		</form>


		<div class="form-group">
			<div id="message" class="col-sm-offset-3 col-sm-6 m-t-15"></div>
		</div>
	</section>
</div>

</div>

<script>
		$(document).ready(function(){
			$('#btn_submit').click(function(){
				validateAndPost();
			})

		})

		function validateAndPost(){
			var name 	 = $('#name').val();
			var password = $('#pwd').val();
			
			if(name == ''){ //check name not empty
				alert('please enter username !!'); 
			}

			else if(password == ''){ //check password not empty
				alert('please enter password !!'); 
			}

			else{		
				$.ajax({
					url: '../api/index.php?action=login',
					type: 'post',
					data:	{
								name : name, 
								password: password,
							},

					success: function(response){
						if(response.status==1){
							$('#message').html('<div class="alert alert-success" role="alert">Logged in successfully</div>');
							setTimeout(() => {
								window.location.href = "index.php";
							}, 1000);
						}

					},

					 error: function(data) {
						successmessage = 'Error';
						$('#message').html(data);
					},

				});
			
				//$('#registraion_form')[0].reset();
			}

		}

	</script>
</body>
</html>