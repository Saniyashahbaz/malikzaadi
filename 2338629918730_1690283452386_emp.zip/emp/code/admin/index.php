<?php
	session_start();

	if(empty($_SESSION['is_logged'])) {
		header("Location:login.php");
	}
?>

<!DOCTYPE html>
<html>
<?php
	include("./header.php");
?>


<body>
	<div class="container" >
			<div class="row">
				<div class="col-md-3">
					<?php include("./left_menu.php"); ?>
				</div>
				
			</div>

		</div>
</body>
</html>