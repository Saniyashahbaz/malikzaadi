<?php
	session_start();
	$role=$_SESSION['role_id'];

	$_SESSION['is_logged']=false;
	$_SESSION['user_id']="";
	$_SESSION['role_id']="";


	//if logged out as admin
	if($role==1){
		header('Location: index.php');
	}

	else{
		header('Location: ../index.php');
	}
?>
