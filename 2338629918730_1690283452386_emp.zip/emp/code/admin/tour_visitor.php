<!DOCTYPE html>
<html>
	<?php
		include("./header.php");
		if($_SESSION['is_logged'] && $_SESSION['role_id']!=1){
			header("Location: login.php");
		}
	?>
	<body>
		<div class="row">
			<div class="col-md-3">
				<?php include("./left_menu.php") ?>
			</div>
			<div class="col-md-9">
				<div class="tbl-tours">
					<table>
						<thead>
							<tr>
								<th class="col-md-3">
									Name
								</th>

								<th class="col-md-3">
									Address
								</th>

								<th class="col-md-3">
									Phone
								</th>

								<th class="col-md-2">
									Email
								</th>
								<th class="col-md-2">
									Action
								</th>
							</tr>
						</thead>

						<tbody id="table-body">
						</tbody>
					</table>
					

					<div id="message">
						<div class="no_record">
						
							<div id="loading-message">Loading...</div>

							<div class="d-flex justify-content-center">
								<div class="spinner-border" role="status">
									<span class="sr-only">Loading...</span>
								</div>
							</div>
						</div>
					</div>

					
				</div>
			</div>

		</div>
	</body>

	<script type="text/javascript">
		$(document).ready(function(){
			loadPlans();
		})

		function loadPlans(){
			$.ajax({
				url: '../api/index.php?action=load_tour_visitor',
				type: 'get',
			
				success: function(response){
					if(response.status==1){
						if(response.data!=null && response.data.length > 0){
							printTourCompanies(response.data);
							$('#message').html('');
						}
						else{
							$('.no_record').html(response.message);
						}
					}

				},

				error: function(data) {
					successmessage = 'Error';
					$('#message').html(data);
				},

			});
		}


		function printTourCompanies(users){
			let str="";

			for(var i=0; i<users.length; i++){
				str+=`<tr>
						<td>${users[i].name}</td>
						<td>${users[i].address}</td>
						<td>${users[i].phone}</td>
						<td>${users[i].email}</td>
						<td><div class="btn btn-danger" onclick="deleteVisitor(${users[i].id})">Delete</div></td>
						</tr>
					`;
			}

			$("#table-body").html(str);
		}

		function deleteVisitor(id){
			$.ajax({
				url: `../api/index.php?action=delete_visitor`,
				type: 'post',
				data:	{
					id : id,
						},
			
				success: function(response){
					if(response.status==1){
						$('#message').html('');
						if(response.data!=null && response.data.length > 0){
							printTourPlans(response.data);
						}
					}

				},

				error: function(data) {
					successmessage = 'Error';
					//$('#message').html(data);
				},

			});
		}

			
	</script>
</html>