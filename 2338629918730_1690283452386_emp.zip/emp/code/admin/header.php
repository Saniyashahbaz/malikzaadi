<?php
    if(!isset($_SESSION)){
        session_start();
    }
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" href="../css/slick/slick.css" />
    <link rel="stylesheet" href="../css/slick/slick.css"/>
    <link rel="stylesheet" href="../css/slick/slick-theme.min.css" />
    <link rel="stylesheet" href="../css/bootstrap/bootstrap.min.css">

    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/main.css">    
</head>

<body>
    <script type="text/javascript" src="../lib/js/popper.min.js"></script>
    <script type="text/javascript" src="../lib/js/jquery.min.js"></script>
    <script type="text/javascript" src="../lib/js/bootstrap.min.js"></script>

    <header>
        <div class="container">
            <a href="" class="logo">
                <img src="../images/logo.png" alt="">
            </a>
        
            <div>
                <?php if($_SESSION['is_logged'] && $_SESSION['role_id']==1): ?>
                    <a href="logout.php"><button id="btn_logout" class="btn">Logout</button></a>
                <?php endif; ?>
            </div>
        </div>
    </header>
</body>
