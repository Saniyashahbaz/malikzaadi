<!DOCTYPE html>
<html>
	<?php
		include("./header.php");
		if($_SESSION['is_logged'] && $_SESSION['role_id']!=1){
			header("Location: login.php");
		}
	?>
	<body>
		<div class="row">
			<div class="col-md-3">
				<?php include("./left_menu.php") ?>
			</div>

			<div class="col-md-9">
				ALL TOURS
				<div class="tbl-tours">

					<table>
						<thead>
							<tr>
								<th class="col-md-3">
									Title
								</th>

								<th class="col-md-3">
									Destination
								</th>

								<th class="col-md-3">
									Date
								</th>

								<th class="col-md-2">
									Status
								</th>

								<th class="col-md-2">
									Status
								</th>
							</tr>
						</thead>

						<tbody id="table-body">
						</tbody>
					</table>
					

					<div id="message">
						<div class="no_record">
						
							<div id="loading-message">Loading...</div>

							<div class="d-flex justify-content-center">
								<div class="spinner-border" role="status">
									<span class="sr-only">Loading...</span>
								</div>
							</div>
						</div>
					</div>

					
				</div>
			</div>

		</div>
	</body>

	<script type="text/javascript">
		$(document).ready(function(){
			loadPlans();
		})

		function loadPlans(){
			$.ajax({
				url: '../api/index.php?action=load_tours',
				type: 'get',
			
				success: function(response){
					if(response.status==1){
						if(response.data!=null && response.data.length > 0){
							printTourPlans(response.data);
							$('#message').html('');
						}
						else{
							$('.no_record').html(response.message);
						}
					}

				},

				error: function(data) {
					successmessage = 'Error';
					$('#message').html(data);
				},

			});
		}


		function printTourPlans(plans){
			let str="";

			for(var i=0; i<plans.length; i++){
				str+=`<tr>
						<td>${plans[i].title}</td>
						<td>${plans[i].destination}</td>
						<td>${plans[i].date}</td>
						<td>${plans[i].status}</td>
						${plans[i].approval=='0' ? `<td><div class="btn btn-success" onclick="approveTour(${plans[i].tp_id})">Approve</div></td>` : '<td><div class="btn btn-success" >Approved</div></td>'}
						}}
					</tr>
					`;
			}

			$("#table-body").html(str);
		}

		function approveTour(tp_id){
			$.ajax({
				url: `../api/index.php?action=approve_tour`,
				type: 'post',
				data:	{
					tp_id : tp_id,
						},
			
				success: function(response){
					if(response.status==1){
						$('#message').html('');
						if(response.data!=null && response.data.length > 0){
							printTourPlans(response.data);
						}
					}

				},

				error: function(data) {
					successmessage = 'Error';
					//$('#message').html(data);
				},

			});
		}
			
	</script>
</html>