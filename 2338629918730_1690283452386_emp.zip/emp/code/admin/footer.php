    <section class="copyright-section">
        <div class="container">
            <p>Explore Mera Pakistan © 2023 All Right Reserved</p>            
            <ul>
                <li>
                    <a href="">Terms of Service</a>
                </li>
                <li>
                    <a href="">Privacy Policy</a>
                </li>
            </ul>
        </div>
    </section>