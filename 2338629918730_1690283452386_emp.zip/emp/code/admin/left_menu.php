<?php
    if(isset($_GET['page'])){
        $page=$_GET['page'];
    }
?>

<div class="left_menu">
    <h5>Menu</h5>

    <ul>
        <li>
            <a href="all_tours.php?page=1"  class="<?php echo isset($page) && $page==1 ? 'menu_item_selected' : 'menu_item'?>">
                All Tours
            </a>
        </li>

        <li>
            <a href="tour_companies.php?page=2"  class="<?php echo isset($page) && $page==2 ? 'menu_item_selected' : 'menu_item'?>">
                Tour Companies
            </a>
        </li>
        <li>
            <a href="tour_visitor.php?page=3"  class="<?php echo isset($page) && $page==3 ? 'menu_item_selected' : 'menu_item'?>">
                Tour Visitor
            </a>
        </li>
    </ul>
</div>