<?php
    class DatabaseConnector {
        private $dbConnection = null;

        public function __construct() {
            $db_host = "localhost";
            $db_name   = "emp";
            $db_user = "root";
            $db_password = "";

            try {
                $this->dbConnection=new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_password);
                $this->dbConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }
            
            catch (\PDOException $e) {
                exit($e->getMessage());
            }
        }

        public function getConnection(){
            return $this->dbConnection;
        }
    }
?>