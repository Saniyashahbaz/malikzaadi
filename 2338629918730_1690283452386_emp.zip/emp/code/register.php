<?php
include("includes/php_includes_top.php");
$strMSG = "";
$class = "";
$strMSG1= "";
$class1 = "";

$role_id = "";
$name = "";
$phone = "";
$address = "";
$email = "";
$password = "";
$cpwd = "";
$city = "";
 if(isset($_REQUEST['btnRegister'])){
     $Query = "SELECT * FROM `users` WHERE email ='".trim($_REQUEST['email'])."' AND role_id = '".trim($_REQUEST['role_id'])."'";
     $rs = mysqli_query($GLOBALS['conn'], $Query);
     if(mysqli_num_rows($rs) > 0){
        $name = $_REQUEST['name'];
        $phone = $_REQUEST['phone'];
        $address = $_REQUEST['address'];
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $cpwd = $_REQUEST['cpwd'];
        $city = ((isset($_REQUEST['city']))?$_REQUEST['city']:'');
        $comapany_name = ((isset($_REQUEST['comapany_name']))?$_REQUEST['comapany_name']:'');
        $class = "alert alert-danger";
        $strMSG = "Dear Cuctomer, <br>
                    This account already exists against the user name!";
     } else {
         if($_REQUEST['password'] != $_REQUEST['cpwd']){
		$role_id = $_REQUEST['role_id'];
        $name = $_REQUEST['name'];
        $phone = $_REQUEST['phone'];
        $address = $_REQUEST['address'];
        $email = $_REQUEST['email'];
        $password = $_REQUEST['password'];
        $cpwd = $_REQUEST['cpwd'];
        $city = $_REQUEST['city'];
        $comapany_name = $_REQUEST['comapany_name'];
		$city = ((isset($_REQUEST['city']))?$_REQUEST['city']:'');
        $comapany_name = ((isset($_REQUEST['comapany_name']))?$_REQUEST['comapany_name']:'');
        $class = "alert alert-danger";
        $strMSG = "Dear Cuctomer, <br>
                    Passwords does not match!";
         } else {
			$dirName = "files/tour_company/";
			$mfileName = "";
			if (!empty($_FILES["user_image"]["name"])) {
				$mfileName = $_FILES["user_image"]["name"];
				$mfileName = str_replace(" ", "_", strtolower($mfileName));
				move_uploaded_file($_FILES['user_image']['tmp_name'], $dirName . $mfileName);
			}
			$user_company_image = "";
			if (!empty($_FILES["user_company_image"]["name"])) {
				$user_company_image = $_REQUEST['name']." ".$_FILES["user_company_image"]["name"];
				$user_company_image = str_replace(" ", "_", strtolower($user_company_image));
				move_uploaded_file($_FILES['user_company_image']['tmp_name'], $dirName . $user_company_image);
			}
             mysqli_query($GLOBALS['conn'],"INSERT INTO users (role_id, name, phone, address, email, password, city, comapany_name, user_image, user_company_image) VALUES ('".trim($_REQUEST['role_id'])."','".trim($_REQUEST['name'])."','".$_REQUEST['phone']."','".trim($_REQUEST['address'])."','".trim($_REQUEST['email'])."','".trim($_REQUEST['password'])."','".trim(((isset($_REQUEST['city']))?$_REQUEST['city']:''))."', '".trim(((isset($_REQUEST['comapany_name']))?$_REQUEST['comapany_name']:''))."', '".$mfileName."', '".$user_company_image."')") or die(mysqli_error($GLOBALS['conn']));
             $class = "alert alert-success";
			$strMSG = "Dear Cuctomer, <br>
            your account has been created successfully. Please <a href='login.php'>login</a> to your account  and enjoy our services";
			
         }
     }
 }
?>

<!DOCTYPE html>
<html lang="en">
    <?php include ("includes/html_header.php") ?>
    <body>
        <?php include("includes/navigation.php"); ?>
        <section id="account-type">
            <div class="container">
                <div class="register-text">
                    <h3 style="text-align: center;"><strong>Let’s find the right account for your needs</strong></h3>
                    <p style="text-align: center;">Please select the option that describes you the best</p>
                    <h3>I'm a</h3>
                </div>
				<div class="form-group">
						<div id="message" class="col-sm-offset-3 col-sm-6 m-t-15"></div>
						<?php if ($class != "") { ?>
							<div class="<?php print($class); ?>"><?php print($strMSG); ?><a href="javascript:void(0);" class="close" data-dismiss="alert">×</a></div>
						<?php } ?>
					</div>
                <div class="register-options">
                    <div class="qOption" data-option="company">
                        <img class="i-am-img img_3" src="./images/icons/company2.png" role="presentation">
                        <div>Tour Company</div>
                    </div>

                     <div class="qOption_visitor" data-option="visitor">
                        <img class="i-am-img img_3" src="./images/icons/visitor1.png" role="presentation">
                        <div>Visitor</div>
                    </div>
                </div>
            </div>
		</section>

		<section id="form-container" style="display: none;">
            <div class="container mt-5">
				<h3>Register</h3>
				<hr>
				<form name="frm" id="frm" method="post" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" class="form-horizontal" role="form" enctype="multipart/form-data">
					<div class="row">
						<div class="col-md-6">
							<input type="hidden" name="role_id" value="2">
							<div class="form-group input-group-lg" >
								<input type="text" id="comapany_name" name="comapany_name" class="form-control" placeholder="Company Name"required>
							</div>

							<div class="form-group input-group-lg">
								<input type="text" id="address" name="address" class="form-control" placeholder="Address" aria-describedby="sizing-addon1">
							</div>
							
							<div class="form-group input-group-lg">
								<input type="text" id="city" name="city" class="form-control" placeholder="City" aria-describedby="sizing-addon1">
							</div>

							<div class="form-group input-group-lg">
								<input type="text" id="phone" name="phone" class="form-control" placeholder="Phone Number" aria-describedby="sizing-addon1">
							</div>
							<div class="form-group input-group-lg">
								<input type="file" class="form-control" title="Tourist Image" name="user_image" id="user_image" required>
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group input-group-lg">
								<input type="text" id="name" name="name" class="form-control" placeholder="Name" aria-describedby="sizing-addon1" required>
							</div>
							<div class="form-group input-group-lg">
								<input type="email" id="email" name="email" class="form-control" placeholder="Email" aria-describedby="sizing-addon1" required>
							</div>

							<div class="form-group input-group-lg">
								<input type="password" id="password" name="password" class="form-control" placeholder="Password" aria-describedby="sizing-addon1" required>
							</div>

							<div class="form-group input-group-lg">
								<input type="password" id="cpwd" name="cpwd" class="form-control" placeholder="Confirm Password" aria-describedby="sizing-addon1" required>
							</div>
							<div class="form-group input-group-lg">
								<input type="file" class="form-control" title="Company Logo" name="user_company_image" id="user_image" required>
							</div>
							
						</div>
					</div>

					<input type="submit" id="btn_register" class="btn btn-success" value="Submit" name="btnRegister">

					
				</form>
			</div>
        </section>
		<section id="form-visitor" style="display: none;">
            <div class="container mt-5">
				<h3>Visitor</h3>
				<hr>
				<form name="frm" id="frm" method="post" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" class="form-horizontal" role="form" enctype="multipart/form-data">
					<div class="row">
						<div class="col-md-6">
							<input type="hidden" name="role_id" value="3">
							<div class="form-group input-group-lg" >
								<input type="text" id="name" name="name" class="form-control" placeholder="Name"required>
							</div>

							<div class="form-group input-group-lg">
								<input type="text" id="address" name="address" class="form-control" placeholder="Address" aria-describedby="sizing-addon1">
							</div>
							
							<div class="form-group input-group-lg">
								<input type="text" id="city" name="city" class="form-control" placeholder="City" aria-describedby="sizing-addon1">
							</div>
							<div class="form-group input-group-lg">
								<input type="file" class="form-control" title="Tourist Image" name="user_image" id="user_image" required>
							</div>
						</div>

						<div class="col-md-6">
							<div class="form-group input-group-lg">
								<input type="email" id="email" name="email" class="form-control" placeholder="Email" aria-describedby="sizing-addon1" required>
							</div>

							<div class="form-group input-group-lg">
								<input type="password" id="password" name="password" class="form-control" placeholder="Password" aria-describedby="sizing-addon1" required>
							</div>
							<div class="form-group input-group-lg">
								<input type="password" id="cpwd" name="cpwd" class="form-control" placeholder="Confirm Password" aria-describedby="sizing-addon1" required>
							</div>
							<div class="form-group input-group-lg">
								<input type="text" id="phone" name="phone" class="form-control" placeholder="Phone Number" aria-describedby="sizing-addon1">
							</div>
							
						</div>
					</div>

					<input type="submit" id="btn_register" class="btn btn-success" value="Submit" name="btnRegister">

					
				</form>
			</div>
        </section>
		<?php
			include ("includes/footer.php");
		?>

<script>
	$(document).ready(function(){
				$('.qOption').click(function(e){
					accountType = e.currentTarget.dataset['option'];
					$("#account-type")[0].style['display']='none';
					$("#form-visitor")[0].style['display']='none';
					$("#form-container")[0].style['display']='block';
				})
				
				$('.qOption_visitor').click(function(e){
					accountType = e.currentTarget.dataset['option'];
					$("#account-type")[0].style['display']='none';
					$("#form-container")[0].style['display']='none';
					$("#form-visitor")[0].style['display']='block';
				})

			})
</script>
		<!--<script type="text/javascript">
			var accountType="";

			$(document).ready(function(){
				$('.qOption').click(function(e){
					accountType = e.currentTarget.dataset['option'];
					$("#account-type")[0].style['display']='none';
					$("#form-container")[0].style['display']='block';
				})

				$('#btn_register').click(function(e){
					validateAndPost();
				})
			})

		function validateAndPost(){
			var name = $('#name').val();
			var address= $('#address').val();
			var phone = $('#phone').val();
			var email 	 = $('#email').val();
			var password = $('#pwd').val();
			var cpassword = $('#cpwd').val();
			var comapany_name = $('#comapany_name');
			var city = $('#city');
			
			var atpos  = email.indexOf('@');
			var dotpos = email.lastIndexOf('.com');
			
			if(name == ''){ // check username not empty
				alert('please enter username !!'); 
			}

			if(address == ''){ // check address not empty
				alert('please enter address !!'); 
			}


			else if(email == ''){ //check email not empty
				alert('please enter email address !!'); 
			}

			else if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length){ //check valid email format
				alert('please enter valid email address !!'); 
			}

			else if(password == ''){ //check password not empty
				alert('please enter password !!'); 
			}

			else if(password.length < 6){ //check password value length six 
				alert('password must be 6 !!');
			} 

			else if(password!=cpassword){ //check password match confirm password
				alert('confirm password must match password');
			} 


			else{		
				$.ajax({
					url: './api/index.php?action=register',
					type: 'post',
					data:	{
								name : name, 
								address: address,
								phone: phone,
								email : email, 
								password: password,
								comapany_name: comapany_name,
								city: city,
								role_id: accountType=='company' ? 2 : 3,
							},

					success: function(response){
						if(response.status==1){
							$('#message').html('<div class="alert alert-success" role="alert">Registeraion completed successfully</div>');
							setTimeout(() => {
								window.location.href = "index.php";
							}, 1000);
						}
						else{
							$('#message').html('<div class="alert alert-danger" role="alert">'+response.message+'</div>');
							setTimeout(() => {
								$('#message').html('');
							}, 2000);
						}

					},

					 error: function(data) {
						successmessage = 'Error';
						$('#message').html(data);
					},

				});
			
				//$('#registraion_form')[0].reset();
			}

		}
		</script>-->
    </body>
</html>
