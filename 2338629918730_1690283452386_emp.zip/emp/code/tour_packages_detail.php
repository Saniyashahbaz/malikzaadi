<?php
 include("includes/php_includes_top.php"); 
 if(isset($_REQUEST['tp_id']) && $_REQUEST['tp_id'] > 0){
    $Query = "SELECT * FROM tour_plans WHERE tp_id = '".$_REQUEST['tp_id']."'";
    $rs = mysqli_query($GLOBALS['conn'], $Query);
    if(mysqli_num_rows($rs) > 0){
        $row = mysqli_fetch_object($rs);
        $title = $row->title;
        $description = $row->description;
        $charges = $row->charges;
        $days = $row->days;
        $tp_night = $row->tp_night;
        $tb_pickup = $row->tb_pickup;
        $tb_drop = $row->tb_drop;
        $tb_stay = $row->tb_stay;
        $tb_accomodation = $row->tb_accomodation;
        $tb_km = $row->tb_km;
        $tb_food = $row->tb_food;
        $tb_image = $row->tb_image;

    }
 } else{
    header('Location:tour_packages.php');
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include("includes/html_header.php"); ?>
</head>

<body>
    <?php include ("includes/navigation.php"); ?>

    <section class="section_container">
        <div class="page_width">
            <h1><?php print($title); ?></h1>
            <div class="tour_package_detail_grid">
                    <div class="tpd_tour_pd_left">
                        <img src="files/tour_plane/<?php print($tb_image); ?>" alt="" srcset="">
                    </div>
                    <div class="tour_pd_right">
                        <div class="tpd_right_upper">
                            <h4><?php print($days); ?> Days <?php print($tp_night); ?> Nights</h4>
                            <h2><?php print($title); ?></h2>
                        </div>
                        <div class="tpd_right_bottom">
                            <ul>
                                <li><span>Total Charges: </span><?php print($charges); ?></li>
                                <li><span>Pickup Point: </span><?php print($tb_pickup); ?></li>
                                <li><span>Drop Point: </span><?php print($tb_drop); ?></li>
                                <li><span>Stay: </span><?php print($tb_stay); ?></li>
                                <li><span>Accommodation: </span><?php print($tb_accomodation); ?></li>
                                <li><span>Total KMs: </span><?php print($tb_km); ?></li>
                                <li><span>Food: </span><?php print($tb_food); ?> Time Meal</li>
                            </ul>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </section>
    <section class="section_container">
        <div class="page_width">
            <h1>Related Tour Packages</h1>
            <div class="tour_package_grid">
            <?php 
                $Query = "SELECT * FROM tour_plans AS tp WHERE tp.approval = '1' AND tp_id != '".$_REQUEST['tp_id']."'";
                $rs = mysqli_query($GLOBALS['conn'], $Query);
                if(mysqli_num_rows($rs) > 0){
                    while($row = mysqli_fetch_object($rs)){
                ?>
                <a href="tour_packages_detail.php?tp_id=<?php print($row->tp_id); ?>">
                    <div class="tour_card">
                        <img src="files/tour_plane/<?php print($row->tb_image); ?>" alt="" srcset="">
                        <div class="tour_text_overlay">
                            <h4><?php print($row->days); ?></Pphp> Days <?php print($row->tp_night); ?> Nights</h4>
                            <h3><?php print($row->title); ?></h3>
                        </div>
                    </div>
                </a>
                <?php 
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <?php include("includes/footer.php") ?>
</body>
<script>
    $('.tour_package_grid').slick({
          dots: false,
          infinite: true,
          slidesToShow: 3,
          slidesToScroll: 1,
          autoplay: true,
          autoplaySpeed: 2000,
          responsive: [
            {
              breakpoint: 1024,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
            // You can unslick at a given breakpoint now by adding:
            // settings: "unslick"
            // instead of a settings object
          ]
        });

</script>
</html>