<?php
include("includes/php_includes_top.php");
if(isset($_REQUEST['action'])) {
    switch ($_REQUEST['action']) {
        case 'search_destination':
            $json = array();
            $where = "";
            if (isset($_REQUEST['term']) && $_REQUEST['term'] != '') {
            $where .= " WHERE name LIKE '%" . $_REQUEST['term'] . "%'";
            }
            $Query = "SELECT * FROM `users` " . $where . " ORDER BY id LIMIT 0,20";
            //print_r( $Query );
            $rs = mysqli_query($GLOBALS['conn'], $Query);
            while ($row = mysqli_fetch_object($rs)) {
                $json[] = array(
                    'id' => strip_tags(html_entity_decode($row->id, ENT_QUOTES, 'UTF-8')),
                    'value' => strip_tags(html_entity_decode($row->name, ENT_QUOTES, 'UTF-8'))
                );
            }
            $jsonResults = json_encode($json);
            print($jsonResults);
        break;
        
    }
}
?>