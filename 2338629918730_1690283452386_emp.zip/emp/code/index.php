<?php include("includes/php_includes_top.php"); ?>
<!DOCTYPE html>
<html lang="en">
   <?php
        include ("includes/html_header.php");

   ?>

    <body>
        <?php include ("includes/navigation.php"); ?>
        <section class="banner">
            <div class="container">
                <div class="inner">
                    <div class="text">
                        <h1 class="main-heading">MOST <span>POPULAR</span> TOURS</h1>
                        <p>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nostrum repellendus obcaecati quisquam itaque laborum necessitatibus suscipit magnam perferendis
                            enim odit?
                        </p>
                        <button class="btn btn-success">Read More</button>
                    </div>
                    <?php include('includes/search_box.php')?>
                </div>
            </div>
        </section>
        <section>
            <div class="container">
                <div class="about-us">
                    <figure class="image-holder">
                        <img src="./images/about-image3.jpg" alt="" />
                    </figure>
                    <div class="description">
                        <p class="sub-heading">WELCOME TO <span>EXPLORE MERA PAKISTAN</span></p>
                        <div class="text">
                            <p class="content">
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi
                                enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor
                                in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim
                                qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.
                            </p>
                            <p class="content">
                                Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi
                                enim ad minim veniam,
                            </p>
                        </div>
                        <button class="btn btn-primary">READ MORE</button>
                    </div>
                </div>
            </div>
        </section>
        <section class="top-tourists">
            <div class="container">
                <div class="sections-heading">TOP TOURISTS</div>
                <div class="grid">
                    <?php 
                    $Query = "SELECT * FROM `users` WHERE `role_id` = '2' AND user_featured = '1'";
                    $rs = mysqli_query($GLOBALS['conn'], $Query);
                    if(mysqli_num_rows($rs) > 0){
                        while($row = mysqli_fetch_object($rs)){
                            $user_image_path = "files/no_img_1.jpg";
                            if(!empty($row->user_image)){
                                $user_image_path = "files/tour_company/".$row->user_image;
                            }
                    ?>
                    <div class="card">
                        <figure>
                            <img src="<?php print($user_image_path); ?>" alt="" />
                        </figure>
                        <div class="details">
                            <div class="name">
                                <h3><?php print($row->name); ?></h3>
                                <p class="content">Tourist</p>
                            </div>
                            <div class="rating">
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <div class="unchecked"></div>
                            </div>
                        </div>
                    </div>
                    <?php 
                    }
                }
                    ?>
                </div>
            </div>
        </section>
        <section class="top-partners">
            <div class="container">
                <div class="sections-heading">TOP REVIEWS</div>
                <div class="grid">
                    <?php 
                    $Query = "SELECT feed.*, u.name, u.user_image FROM `feedbacks` AS feed LEFT OUTER JOIN users AS u ON u.id = feed.user_id  ORDER BY  RAND() LIMIT 0,3";
                    $rs = mysqli_query($GLOBALS['conn'], $Query);
                    if(mysqli_num_rows($rs) > 0){
                        while($row = mysqli_fetch_object($rs)){
                            $user_image_path = "files/no_img_1.jpg";
                            if(!empty($row->user_image)){
                                $user_image_path = "files/tour_company/".$row->user_image;
                            }
                    ?>
                    <div class="grid-item">
                        <figure class="rounded-image">
                            <img src="<?php print($user_image_path); ?>" alt="" />
                        </figure>
                        <div class="details">
                            <div class="name">
                                <h3><?php print($row->name); ?></h3>
                                <p class="content">Tourist</p>
                            </div>
                            <div class="rating">
                                <?php 
                                if($row->rating > 0 && $row->rating <= 5){
                                    for($i = 0; $i < 5; $i++){
                                        if($row->rating > $i){?>
                                    <div class="checked"></div>
                                    <?php } else { ?>
                                        <div class="unchecked"></div> 
                                    <?php } } 
                                } else {?>
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <div class="checked"></div>
                                <?php } ?> 
                            </div>
                        </div>
                        <div class="description">
                            <p>Vulputate vulputate mauris primis viverra quis netus leo voluptates. Placerat, feugiat nascetur placerat.</p>
                        </div>
                    </div>
                    <?php
                    }
                }
                    ?>
                </div>
            </div>
        </section>
        <section class="top-events">
            <div class="container">
                <div class="sections-heading">TOP DESTINATIONS</div>
                <div class="grid">
                    <?php 
                    $Query = "SELECT * FROM `tour_plans` ORDER BY  RAND() LIMIT 0,3";
                    $rs = mysqli_query($GLOBALS['conn'], $Query);
                    if(mysqli_num_rows($rs) > 0){
                        while($row = mysqli_fetch_object($rs)){
                    ?>
                    <div class="grid-item">
                        <figure class="card-image">
                            <img src="files/tour_plane/<?php print($row->tb_image); ?>" alt="" />
                        </figure>
                        <div class="description">
                            <div class="details">
                                <h3><?php print($row->title); ?></h3>
                                <p class="content">
                                <?php print($row->description); ?>
                                </p>
                            </div>
                            <div class="more">
                                <h4><?php print(date('D F j, Y ', strtotime($row->date))); ?></h4>
                                <a href="tour_packages_detail.php?tp_id=<?php print($row->tp_id); ?>">
                                    <span>READ MORE</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php 
                    }

                }
                    ?>
                </div>
                <button class="btn btn-primary" onclick="javascript: window.location ='tour_packages.php'">MORE DESTINATIONS</button>
            </div>
        </section>

        <?php include("includes/footer.php") ?>

    </body>
    <?php include("includes/bottom_js.php") ?>
</html>
