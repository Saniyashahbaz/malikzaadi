<?php
//$sessTime = 24*60*60;
//ini_set('session.gc_maxlifetime', $sessTime);
//ini_set('session.gc_probability', 1);
//ini_set('session.gc_divisor', 1);
ini_set('display_errors', 1);
error_reporting(E_ALL);
if($_SERVER['HTTP_HOST']=='localhost:82'){
	$dbServer   = "localhost";
	$dbDatabase = "emp";
	$dbUserName = "root";
	$dbPassword = "";
    $GLOBALS['siteURL'] = "http://localhost:82/emp/";
}
elseif($_SERVER['HTTP_HOST']=='localhost'){
	$dbServer   = "localhost";
	$dbDatabase = "emp";
	$dbUserName = "root";
	$dbPassword = "";
    $GLOBALS['siteURL'] = "http://localhost/emp/";
}
else{
    $dbServer   = "localhost";
    $dbDatabase = "crowd_vcrowdfund";
	$dbUserName = "crowd_vcrowdfund";
    $dbPassword = "";
    $GLOBALS['siteURL'] = "http://www.vcrowdfund.com/";
}
$GLOBALS['conn'] = new mysqli($dbServer, $dbUserName, $dbPassword, $dbDatabase);
mysqli_set_charset($GLOBALS['conn'], 'utf8');
?>
