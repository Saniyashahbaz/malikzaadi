<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="../css/jquery-ui-1.10.3.custom.min.css" />
        <script src="../lib/js/jquery-2.2.0.min.js"></script>
</head>
<body>
    <input type="text" class="name">
</body>
<script src="../lib/js/jquery-ui-1.10.3.custom.min.js"></script>
<script>
    
    $('input.name').autocomplete({
        
        source: function( request, response ) {
            $.ajax( {
                url: 'ajax_calls.php?action=name',
                dataType: "json",
                data: {
                    term: request.term
                },
                success: function( data ) {
                    response( data );
                   // console.log(data);

                }
            } );
        },
        minLength: 1,
        select: function( event, ui ) {
            var name = $("#name");
           // var rep_auther_id = $("#rep_auther_id");
            //$(rep_auther_id).val(ui.item.rep_auther_id);
            $(name).val(ui.item.value);

           // return false;
            //console.log( "Selected: " + ui.item.value + " aka " + ui.item.id );
        }
    });
</script>
</html>