<?php
 include("includes/php_includes_top.php");
 if(isset($_SESSION['role_id']) && $_SESSION['role_id'] == 3){
	header("LOcation:tourist_company.php");
 }
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
<?php include("includes/html_header.php"); ?>
</head>

<body>
	<header>
		<div class="container">
			<a href="index.php" class="logo">
				<img src="./images/logo.png" alt="" />
			</a>

			<div class="btns">
				Your are logged in as: <span><?php echo ($_SESSION['name']); ?></span>
				<a href="./admin/logout.php"><button class="btn btn-success">Logout</button></a>
			</div>
		</div>
	</header>

	<div class="container">
		<div>
			<div class="tbl-tours">
				<div class="admin-heading">
					<h3>Manage Tours</h3>
					<a href="./create_tour.php">
						<button type="button" class="btn btn-primary">Add Tour</button>
					</a>

				</div>

				<table>
					<thead>
						<tr>
							<th class="col-md-3">
								Title
							</th>

							<th class="col-md-3">
								Destination
							</th>

							<th class="col-md-3">
								Date
							</th>

							<th class="col-md-2">
								Status
							</th>

							<th class="col-md-2">
								Approval
							</th>
						</tr>
					</thead>

					<tbody id="table-body">
					</tbody>
				</table>


				<div id="message">
					<div class="no_record">
						<div id="loading-message">Loading...</div>
						<div class="d-flex justify-content-center">
							<div class="spinner-border" role="status">
								<span class="sr-only">Loading...</span>
							</div>
						</div>
					</div>
				</div>


			</div>
		</div>

	</div>

	<?php include("includes/footer.php") ?>


	<script type="text/javascript">
		$(document).ready(function() {
			loadPlans();
		})

		function loadPlans() {
			$.ajax({
				url: './api/index.php?action=load_company_tours',
				type: 'get',

				success: function(response) {
					if (response.status == 1) {
						$('#message').html('');
						if (response.data != null && response.data.length > 0) {
							printTourPlans(response.data);
						}
					} else {
						$('.no_record').html('No Tour plans found');
					}

				},

				error: function(data) {
					successmessage = 'Error';
					//$('#message').html(data);
				},

			});
		}


		function printTourPlans(plans) {
			let str = "";

			for (var i = 0; i < plans.length; i++) {
				str += `<tr>
						<td>${plans[i].title}</td>
						<td>${plans[i].destination}</td>
						<td>${plans[i].date}</td>
						<td>${plans[i].status}</td>
                        <td>${plans[i].approval==0 ? '<span style="color: red">Pending</span>' : '<span style="color: green">Approved</span>'}</td>
					</tr>
					`;
			}

			$("#table-body").html(str);
		}
	</script>
</body>

</html>