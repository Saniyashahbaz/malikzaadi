<?php include("includes/php_includes_top.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include("includes/html_header.php"); ?>
</head>

<body>
    <?php include ("includes/navigation.php"); ?>

    <section class="section_container">
        <div class="page_width">
            <h1>Tour Packages</h1>
            <div class="tour_package_grid">
                <?php 
                $Query = "SELECT * FROM tour_plans AS tp WHERE tp.approval = '1'";
                $rs = mysqli_query($GLOBALS['conn'], $Query);
                if(mysqli_num_rows($rs) > 0){
                    while($row = mysqli_fetch_object($rs)){
                ?>
                <a href="tour_packages_detail.php?tp_id=<?php print($row->tp_id); ?>">
                    <div class="tour_card">
                        <img src="files/tour_plane/<?php print($row->tb_image); ?>" alt="" srcset="">
                        <div class="tour_text_overlay">
                            <h4><?php print($row->days); ?></Pphp> Days <?php print($row->tp_night); ?> Nights</h4>
                            <h3><?php print($row->title); ?></h3>
                        </div>
                    </div>
                </a>
                <?php 
                    }
                }
                ?>
            </div>
        </div>
    </section>

    <?php include("includes/footer.php") ?>
</body>

</html>