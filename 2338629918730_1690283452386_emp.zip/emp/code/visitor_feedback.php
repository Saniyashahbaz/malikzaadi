<?php
include("includes/php_includes_top.php");
$strMSG = "";
$class = "";

 if(isset($_REQUEST['btnRegister'])){
     $Query = "SELECT * FROM `feedbacks` WHERE company_id  ='".trim($_REQUEST['company_id'])."' AND user_id  = '".trim($_SESSION['user_id'])."'";
     $rs = mysqli_query($GLOBALS['conn'], $Query);
     if(mysqli_num_rows($rs) > 0){
        $class = "alert alert-danger";
        $strMSG = "Dear Cuctomer, <br>
                    Your feedback already send!";
     } else {
             mysqli_query($GLOBALS['conn'],"INSERT INTO feedbacks (company_id, user_id, rating, feedback_text) VALUES ('".trim($_REQUEST['company_id'])."', '".trim($_SESSION['user_id'])."', '".$_REQUEST['rating']."','".trim($_REQUEST['feedback_text'])."')") or die(mysqli_error($GLOBALS['conn']));
             $class = "alert alert-success";
			$strMSG = "Dear Cuctomer, <br>
            Your feedback send successfully!";
     }
 }
?>

<!DOCTYPE html>
<html lang="en">
    <?php include ("includes/html_header.php") ?>
    <body>
        <?php include("includes/navigation.php"); ?>

		<section id="form-container">
            <div class="container mt-5">
				<h3>Feedback</h3>
				<hr>
				<form name="frm" id="frm" method="post" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" class="form-horizontal" role="form" enctype="multipart/form-data">
					<div class="row">
						<div class="col-md-6">
						<div id="message" class="col-sm-offset-3 col-sm-6 m-t-15"></div>
						<?php if ($class != "") { ?>
							<div class="<?php print($class); ?>"><?php print($strMSG); ?><a href="javascript:void(0);" class="close" data-dismiss="alert">×</a></div>
						<?php } ?>
							<div class="form-group input-group-lg" >
								<select name="rating" id="rating" class="form-control">
									<option value="0">Rating</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
							</div>

							<div class="form-group input-group-lg">
								<textarea type="text" id="feedback_text" name="feedback_text" class="form-control" placeholder="Feedback" aria-describedby="sizing-addon1"></textarea>
							</div>
						</div>

					</div>

					<input type="submit" id="btn_register" class="btn btn-success" value="Submit" name="btnRegister">

					
				</form>
			</div>
        </section>
		<?php
			include ("includes/footer.php");
		?>

    </body>
</html>
