<?php 
include("includes/php_includes_top.php");
//echo $_SESSION['user_id'];
if(isset($_REQUEST['btn_submit'])){
	$mfileName = "";
	$dirName = "files/tour_plane/";
	if (!empty($_FILES["tb_image"]["name"])) {
		$mfileName = $_FILES["tb_image"]["name"];
		$mfileName = str_replace(" ", "_", strtolower($mfileName));
		move_uploaded_file($_FILES['tb_image']['tmp_name'], $dirName . $mfileName);
	}
	mysqli_query($GLOBALS['conn'], "INSERT into tour_plans (company_id, title, description, charges, destination, days, date, tp_night, tb_pickup, tb_drop, tb_stay, tb_accomodation, tb_km, tb_food, tb_image) VALUES ('".$_SESSION['user_id']."', '".$_REQUEST['title']."', '".$_REQUEST['description']."', '".$_REQUEST['charges']."', '".$_REQUEST['destination']."', '".$_REQUEST['days']."', '".$_REQUEST['date']."', '".$_REQUEST['tp_night']."', '".$_REQUEST['tb_pickup']."', '".$_REQUEST['tb_drop']."', '".$_REQUEST['tb_stay']."', '".$_REQUEST['tb_accomodation']."', '".$_REQUEST['tb_km']."', '".$_REQUEST['tb_food']."', '".$mfileName."')") or die(mysqli_error($GLOBALS['conn']));
	header('Location:company_home.php');
}
?>
<!DOCTYPE html>
<html>
	<head>
		<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB7OEdDb4U8wdLbCVu4aUQhfyCnSzGY454&libraries=places"></script>
	</head>

	<?php include("includes/html_header.php"); ?>

	<body>
		<header>
            <div class="container">
                <a href="index.php" class="logo">
                    <img src="./images/logo.png" alt="" />
                </a>
                <nav>
                    <a href="index.php" class="nav-item">HOME</a>
                    <a href="company_home.php" class="nav-item">MY PLANS</a>
                </nav>

                <div class="btns">
                    <!--Your are logged in as: <span><?php echo($_SESSION['name']);?></span>-->
                    <a href="./admin/logout.php"><button class="btn btn-success">Logout</button></a>
                </div>
            </div>
        </header>
		<div class="container">
			
			<div>
				<div class="tbl-tours">
					<div class="admin-heading">
						<h3>Create Tour Plan</h3>
					</div>
					<hr/>
					<form name="frm" id="frm" method="post" action="<?php print($_SERVER['PHP_SELF'] . "?" . $_SERVER['QUERY_STRING']); ?>" class="form-horizontal" role="form" enctype="multipart/form-data">
					<div class="form-destinations">
						<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Tour Title</label>
										<input type="text" class="form-control" name="title" id="title" placeholder="Title">
									</div>
									<div class="form-group">
										<label>Pickup Point</label>
										<input type="text" class="form-control" name="tb_pickup" id="tb_pickup" placeholder="Pickup Point">
									</div>
									<div class="form-group">
										<label>Stay</label>
										<select class="form-control" name="tb_stay" id="tb_stay">
											<option>No</option>
											<option>Yes</option>
										</select>
									</div>

									<div class="form-group">
										<label>Destination</label>
										<input type="text" class="form-control" name="destination" id="destination">
									</div>
									<div class="form-group">
										<label>Days</label>
										<select class="form-control" name="days" id="days">
											<option value="1">1</option>
											<option value="2">2</option>
											<option value="3">3</option>
											<option value="4">4</option>
											<option value="5">5</option>
											<option value="6">6</option>
											<option value="7">7</option>
											<option value="8">8</option>
											<option value="9">9</option>
											<option value="10">10</option>
										</select>
									</div>
									<div class="form-group">
										<label>Meal</label>
										<select class="form-control" name="tb_food" id="tb_food">
											<option value="1" >1</option>
											<option value="2" >2</option>
											<option value="3" >3</option>
										</select>
									</div>
									<div class="form-group">
										<label>Tour Description</label>
										<textarea class="form-control" name="description" id="description"></textarea>
									</div>
									<div class="form-group">
										<label>Image</label>
										<input type="file" class="form-control" name="tb_image" id="tb_image">
									</div>
								</div>

								<div class="col-md-6">
									<div class="form-group">
										<label>Charges</label>
										<input type="number" class="form-control" name="charges" id="charges" placeholder="Charges">
									</div>
									<div class="form-group">
										<label>Drop Point</label>
										<input type="text" class="form-control" name="tb_drop" id="tb_drop" placeholder="Drop Point">
									</div>
									<div class="form-group">
										<label>Accommodation</label>
										<select class="form-control" name="tb_accomodation" id="tb_accomodation">
											<option>No</option>
											<option>Yes</option>
										</select>
									</div>
									<div class="form-group">
										<label>Tour Date</label>
										<input type="date" class="form-control" name="date" id="date">
									</div>
									<div class="form-group">
										<label>Night</label>
										<select class="form-control" name="tp_night" id="tp_night">
											<option value="1" >1</option>
											<option value="2" >2</option>
											<option value="3" >3</option>
											<option value="4" >4</option>
											<option value="5" >5</option>
											<option value="6" >6</option>
											<option value="7" >7</option>
											<option value="8" >8</option>
											<option value="9" >9</option>
											<option value="10" >10</option>
										</select>
									</div>
									<div class="form-group">
										<label>KM</label>
										<input type="text" class="form-control" name="tb_km" id="tb_km" placeholder="KM">
									</div>
								</div>
							</div>
						
					</div>
					<button type="submit" name="btn_submit" id="btn-submit" class="btn btn-1 btn-success">Submit</button>
					</form>
				</div>

			</div>

			<div id="message">
			</div>
		</div>

		
	</body>

	<script>
		var input = document.getElementById('destination');
    	var autocomplete = new google.maps.places.Autocomplete(input,{types: ['(cities)']});
		google.maps.event.addListener(autocomplete, 'place_changed', function(){
			var place = autocomplete.getPlace();
		});



		/*$(document).ready(function(){
			$('#btn-submit').click(function(){
				validateAndPost();
			})
		})*/



		function validateAndPost(){
			var title 		= $('#title').val();
			var destination	= $('#destination').val();
			var description = $('#description').val();
			var charges		= $('#charges').val();
			var date		= $('#date').val();
			var tb_image 	= $('#tb_image').val();

			if(title == '' || destination=='' || description=='' || charges=='' || date=='' || tb_image == ''){ // check username not empty
				alert('please fill all fields'); 
			}

			else{
				console.log("Form Data: "+$("#frm").serialize());		
				$.ajax({
					url: './api/index.php?action=create_tour',
					type: 'post',
					data:	$("#frm").serialize(),
					dataType: "json",
					success: function(response){
						if(response.status==1){
							$('#message').html('<div class="alert alert-success" role="alert">Tour plan created successfully</div>');
							setTimeout(() => {
								window.location.href = "company_home.php";
							}, 2000);
						}
						else{
							$('#message').html('<div class="alert alert-danger" role="alert">'+response.message+'</div>');
							setTimeout(() => {
								$('#message').html('');
							}, 2000);
						}

					},

					 error: function(data) {
						successmessage = 'Error';
						$('#message').html(data);
					},

				});
			
				//$('#registraion_form')[0].reset();
			}

		}
    </script>

</html>