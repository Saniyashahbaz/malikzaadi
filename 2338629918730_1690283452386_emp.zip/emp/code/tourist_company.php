<?php include("includes/php_includes_top.php"); ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <?php include("includes/html_header.php"); ?>
</head>

<body>
    <?php include ("includes/navigation.php"); ?>

    <section class="section_container">
        <div class="page_width">
            
            <h1>Tourist Company <?php print(((isset($_SESSION['role_id']) && $_SESSION['role_id'] == 3))? 'Feadback':''); ?> </h1>
            <div class="tourist_company_grid">
                <?php 
                $Query = "SELECT * FROM users WHERE role_id = '2'";
                $rs = mysqli_query($GLOBALS['conn'], $Query);
                if(mysqli_num_rows($rs) > 0){
                    while($row = mysqli_fetch_object($rs)){
                        $user_company_image_path = "files/no_img_1.jpg";
                            if(!empty($row->user_company_image)){
                                $user_company_image_path = "files/tour_company/".$row->user_company_image;
                            }
                ?>
                <a href="<?php print(((isset($_SESSION['role_id']) && $_SESSION['role_id'] == 3))? 'visitor_feedback.php?company_id='.$row->id:'javascript:void(0);'); ?>">
                <div class="tourist_company_card">
                    <div class="tcc_left">
                        
                        <img src="<?php print($user_company_image_path); ?>" alt="">
                    </div>
                    <div class="tcc_right">
                        <div class="content_upper">
                            <p><span>Name: </span> <?php print($row->name); ?> </p>
                            <p><span>Contact No: </span><?php print($row->phone); ?></p>
                        </div>
                        <div class="content_bottom">
                            <p><span>Address: </span><?php print($row->address); ?></p>
                        </div>
                    </div>
                </div>
                </a>
                <?php 
                 }
                }
                ?>
            </div>
        </div>
    </section>

    <?php include("includes/footer.php") ?>
</body>

</html>