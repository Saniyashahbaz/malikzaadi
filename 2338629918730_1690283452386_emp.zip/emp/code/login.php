<!DOCTYPE html>
<html lang="en">
    <?php include ("includes/html_header.php") ?>
    <body>
        
		<section>
			<div class="row">
				<div class="login-container">
					<div class="login-logo">
						<a href="inde.php" class="logo">
                    		<img src="./images/logo.png" alt="" width="200" />
                		</a>
					</div>
					<form class="login-form">
						<div class="form-group input-group-lg">
							<input type="text" id="email" name="email" class="form-control" placeholder="Email" aria-describedby="sizing-addon1" required>
						</div>

						<div class="form-group input-group-lg">
							<input type="password" id="pwd" name="pwd" class="form-control" placeholder="Password" aria-describedby="sizing-addon1" required>
							<span class="logInForm__forgetPassword"><a id="forgot-password-link" href="#" data-uw-rm-brl="false"> Forgot password?  </a></span>
						</div>

						<input id="btn_login" class="btn btn-success" value="Sign In" name="register">
						<div class="logInForm__signUp">New to Site? <a href="register.php" data-uw-rm-brl="false">Sign up!</a></div>

						<div class="form-group">
							<div id="message" class="col-sm-offset-3 col-sm-6 m-t-15"></div>
						</div>
					</form>
				</div>

				<div class="login-img">
					<img src="./images/banner-image4.jpg" heigh="100%" />
				</div>
			</div>
        </section>

		<script type="text/javascript">
			var accountType="";

			$(document).ready(function(){
				$('.qOption').click(function(e){
					accountType = e.currentTarget.dataset['option'];
					$("#account-type")[0].style['display']='none';
					$("#form-container")[0].style['display']='block';
				})

				$('#btn_login').click(function(e){
					validateAndPost();
				})
			})

		function validateAndPost(){
			var email 	 = $('#email').val();
			var password = $('#pwd').val();
			
			var atpos  = email.indexOf('@');
			var dotpos = email.lastIndexOf('.com');
			
			if(email == ''){ //check email not empty
				alert('please enter email address !!'); 
			}

			else if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length){ //check valid email format
				alert('please enter valid email address !!'); 
			}

			else if(password == ''){ //check password not empty
				alert('please enter password !!'); 
			}

			else{		
				$.ajax({
					url: './api/index.php?action=login',
					type: 'post',
					data:	{
								email : email, 
								password: password,
							},

					success: function(response){
						if(response.status==1){
							$('#message').html('<div class="alert alert-success" role="alert">Logged In successfully</div>');
							setTimeout(() => {
								//window.location.href = "index.php";
								window.location.href = "company_home.php";
							}, 1000);
						}
						else{
							$('#message').html('<div class="alert alert-danger" role="alert">'+response.message+'</div>');
							setTimeout(() => {
								$('#message').html('');
							}, 2000);
						}

					},

					 error: function(data) {
						successmessage = 'Error';
						$('#message').html(data);
					},

				});
			
				//$('#registraion_form')[0].reset();
			}

		}
		</script>
    </body>
</html>
