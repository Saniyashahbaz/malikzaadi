<!DOCTYPE html>
<html lang="en">
   <head>
   <?php include ("includes/html_header.php"); ?>
   </head>

    <body>
       <?php include("includes/navigation.php"); ?>
        <section class="search_results">
            <div id="results">
                <div id="search_loader">
                    <div class="search-spinner d-flex justify-content-center">
                        <div class="spinner-border" role="status">
                            <span class="sr-only">Searching...</span>
                        </div>
                    </div>
                </div>

            </div>

        </section>

        <?php include("includes/footer.php") ?>

        <script>
            $(document).ready(function(){
                if(window.location.search!=''){
                    let search=window.location.search.split("&");
                    //console.log(search);
                    let place=search[0].split("=")[1];
                    console.log(place);
                    let comapany_name=search[1].split("=")[1];
                    console.log(comapany_name);
                    let tp_city=search[2].split("=")[1];
                    //console.log(tp_city);
                    let date=search[3].split("=")[1];
                    //console.log(date);
                    $.ajax({
                        url: './api/index.php?action=search_destinations',
                        type: 'post',
                        data:	{
                            place: place,
                            comapany_name: comapany_name,
                            tp_city: tp_city,
                            date: date,
                                },

                        success: function(response){
                            if(response.status==1 && response.data!=null){
                                $('#results').html('<div class="alert alert-success" role="alert">Search Resuls found</div>');
                                showResults(response.data);
                            }
                            else{
                                $('#results').html('<div class="alert alert-danger" role="alert">'+response.message+'</div>');
                            }

                        },

                        error: function(data) {
                            successmessage = 'Error';
                            $('#results').html(data);
                        },

                    });
                    
                }
            })

            function showResults(plans){
                let str="";

                for(var i=0; i<plans.length; i++){
                    str+=`<div class="row p-2 bg-white border rounded mt-2 ml-3 mr-3">
                            <div class="col-md-3 mt-1"><img class="img-responsive rounded product-image" src="${plans[i].user_company_image ? 'files/tour_company'+plans[i].user_company_image : 'files/no_img_1.jpg'}" height="120"></div>
                <div class="col-md-6 mt-1">
                    <h5>${plans[i].days} day ${plans[i].title}</h5>
                    <!--<div class="d-flex flex-row" style="color: green">
                        <div class="ratings mr-2"><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i></div><span>4.0</span>
                    </div>-->
                    <div class="mt-1 mb-1 spec-1"><span style="color: black">${plans[i].destination}</span></div>
                    <p class="text-justify text-truncate para mb-0">${plans[i].description}</p>
                </div>
                <div class="align-items-center align-content-center col-md-3 border-left mt-1">
                    <div class="d-flex flex-row align-items-center">
                        <h4 class="mr-1">Rs. ${plans[i].charges}</h4>
                    </div>
                    <!--<h6 class="text-success">Every week</h6>-->
                    <div class="d-flex flex-column mt-4"><button class="btn btn-primary btn-sm" type="button" onClick="javascript: window.location = 'tour_packages_detail.php?tp_id=${plans[i].tp_id}'">Details</button>
                    <!--<button class="btn btn-outline-primary btn-sm mt-2" type="button">Mark as interested</button>--></div>
                </div>
            </div>
                        `;
                }

                //    $("#table-body").html(str);
                $("#results").html(str);
            }

        </script>

    </body>
</html>
