<?php
ob_start();
include("lib/openCon.php");

session_start();
?>