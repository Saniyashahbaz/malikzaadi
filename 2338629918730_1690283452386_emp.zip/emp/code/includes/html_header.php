<?php //session_start();
    
?>    
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Home</title>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=Golos+Text:wght@400;500;600;700;800;900&family=Poppins:ital wght@0 100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100&family=Tilt+Warp&display=swap"
            rel="stylesheet"
        />
        <!--<link rel="stylesheet" type="text/css" href="slick/slick.css" />-->
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.css"
            integrity="sha512-wR4oNhLBHf7smjy0K4oqzdWumd+r5/+6QO/vDda76MW5iug4PT7v86FoEkySIJft3XA0Ae6axhIvHrqwm793Nw=="
            crossorigin="anonymous"
            referrerpolicy="no-referrer"
        />
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css"
            integrity="sha512-17EgCFERpgZKcm0j0fEq1YCJuyAWdz9KUtv1EjVuaOz8pDnh/0nZxmU6BBXwaaxqoi9PQXnRWqlcDB027hgv9A=="
            crossorigin="anonymous"
            referrerpolicy="no-referrer"
        />
        
        <link rel="stylesheet" href="./css/global.css" />
        <link rel="stylesheet" href="./css/main.css" />
        <link rel="stylesheet" href="./css/bootstrap/bootstrap.min.css" />

        <script type="text/javascript" src="./lib/js/jquery.min.js"></script>
        <script type="text/javascript" src="./lib/js/bootstrap.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <!--<script>
            $(".slider").slick({
                dots: true,
                infinite: false,
                speed: 300,
                slidesToShow: 2,
                slidesToScroll: 1,
                responsive: [
                    {
                        breakpoint: 1024,
                        settings: {
                            slidesToShow: 2,
                            slidesToScroll: 1,
                            infinite: true,
                            dots: true,
                        },
                    },
                ],
            });
        </script>-->

        <?php 
        $loggedIn=false;
        if(isset($_SESSION) && isset($_SESSION['is_logged']) && $_SESSION['role_id']!=1){
            $loggedIn=true;

            //Check if logged in as company then redirect to company home page.
            /*if($_SESSION['role_id']=='2'){
                header("Location: company_home.php");
            }*/
        }
        ?>

    </head>
