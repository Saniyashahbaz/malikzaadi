<html>

    <body>
    <div class="container">
        <div class="row d-flex justify-content-center">
            <div class="col-md-10">
                <div class="search-card p-3 py-4">
                    <h5>An Easier way to find Destination Points</h5>
                    <div class="row g-3 mt-2">
                        <div class="col-md-9">
                                <input type="text" class="form-control" name="" id="search_destination" class="search_destination" placeholder="Enter address e.g. street, city " />
                        </div>

                        <div class="col-md-3">
                            <button id="btn-search" class="btn btn-success btn-block">Search</button>
                        </div>
                    </div>

                    <div class="mt-3">
                        <a data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample" class="advanced">
                            Advance Search With Filters <i class="fa fa-angle-down"></i>
                        </a>

                        <div class="collapse" id="collapseExample">
                            <div class="advance-search">
                                <div class="row">
                                    <div class="col-md-4">
                                        <input type="text" id="comapany_name" placeholder="Search by Company" class="form-control" />
                                    </div>

                                    <div class="col-md-4">
                                        <input type="text" id="tp_city" class="form-control" placeholder="Search by City" />
                                    </div>

                                    <div class="col-md-4">
                                        <input type="date" id="date" class="form-control" placeholder="Search by Date" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('.search_destination').on('change', function(){
            console.log("search_destination");
        });
    </script>
    <script>
            $(document).ready(function(){
                $("#btn-search").click(validateAndPost);
            })

            function validateAndPost(){
                let place=$("#search_destination").val();
                let comapany_name=$("#comapany_name").val();
                let tp_city=$("#tp_city").val();
                let date=$("#date").val();
                if(place !="" || comapany_name != "" || tp_city != "" || date != ""){
                    window.location.href=`search_results.php?search=${place.split(" ")[0]}&comapany_name=${comapany_name.split(" ")[0]}&tp_city=${tp_city.split(" ")[0]}&date=${date.split(" ")[0]}`;
                }
                else{
                    alert("Please enter a destination");
                }
            }

    </script>
</body>
