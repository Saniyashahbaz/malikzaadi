<header>
    <div class="container">
        <a href="index.php" class="logo">
            <img src="./images/logo.png" alt="" />
        </a>
        <nav>
            <a href="index.php" class="nav-item">Home</a>
            <a href="" class="nav-item">About Us</a>
            <a href="tour_packages.php" class="nav-item">Tour Package</a>
            <a href="tourist_company.php" class="nav-item">Tourist Company</a>
            <a href="" class="nav-item">Contact Us</a>
        </nav>

        <?php if($loggedIn): ?>
            <div>
                <a href="logout.php"><button class="btn btn-success">Logout</button></a>
                <a href="company_home.php"><button class="btn">My Account</button></a>
            </div>
        <?php else: ?>
            <div class="btns">
                <a href="login.php"><button class="btn btn-success">Sign In</button></a>
                <a href="register.php"><button class="btn">Register</button></a>
            </div>
        <?php endif; ?>

    </div>
</header>