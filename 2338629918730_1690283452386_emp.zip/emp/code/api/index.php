<?php
    session_start();
    include("./Api.php");

    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");

    $api=new Api();

    $action="";
    if(isset($_REQUEST['action'])){
        $action=$_REQUEST['action'];
    }

    if($action){
       
        $result=$api->{$action}($_POST);
        /*if($action=='register'){
            $result=$api->register($_POST);
        }
        else if($action=='login'){
            $result=$api->login($_POST);
        }

        else if($action=='login'){
            $result=$api->login($_POST);
        }*/

        echo json_encode($result);	
    }
    else{
        echo('No Action defined');
        exit();
    }


?>