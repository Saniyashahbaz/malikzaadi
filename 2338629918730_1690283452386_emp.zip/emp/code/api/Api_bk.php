<?php
    require_once('../db_connection.php');
    //session_start();

    class Api{
        private $connection = null;
        
         public function __construct() {
            $this->connection=(new DatabaseConnector())->getConnection();
         }

        public function login($params){
            //Check if admin login
            if(isset($_POST['name'])){
                $stmt=$this->connection->prepare("SELECT * FROM users WHERE name=:name and password=:password"); 
                $stmt->bindValue(":name",$params['name']);
                $stmt->bindValue(":password",$params['password']);
            }

            //Visitor or Company
            else{
                $stmt=$this->connection->prepare("SELECT * FROM users WHERE email=:email and password=:password"); 
                $stmt->bindValue(":email",$params['email']);
                $stmt->bindValue(":password",$params['password']);
            }

            $stmt->execute();

            if ($stmt->rowCount() > 0){
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                $_SESSION['is_logged']=true;
                $_SESSION['user_id']=$row['id'];
                $_SESSION['name']=$row['name'];
                $_SESSION['role_id']=$row['role_id'];
                return array('status'=>1, 'message' => 'Logged In successfully', 'user_id' => $row['id']);

            }
            else{
                return array('status'=>0, 'message' => 'User not found');
            }
       }

        public function register($params){
            $exists=$this->checkRecord('users', 'email', $params['email']);
            if($exists){
                 return array('status'=>0, 'message' => 'User already exists, please change email');
            }

            $stmt=$this->connection->prepare("INSERT into users (name, address, phone, email, password, role_id) VALUES (:name, :address, :phone, :email, :password, :role_id)"); 
            $stmt->bindValue(":name",$params['name']);
            $stmt->bindValue(":address",$params['address']);
            $stmt->bindValue(":phone",$params['phone']);
            $stmt->bindValue(":email",$params['email']);
            $stmt->bindValue(":password",$params['password']);
            $stmt->bindValue(":role_id",$params['role_id']);

            $stmt->execute();

            if ($stmt){
                $id = $this->connection->lastInsertId();
                $_SESSION['is_logged']=true;
                $_SESSION['user_id']=$id;
                $_SESSION['name']=$params['name'];
                $_SESSION['role_id']=$params['role_id'];

                return array('status'=>1, 'message' => 'User registered successfully', 'user_id' => $id);
            }
            else{
                return array('status'=>0, 'message' => 'Error registeration');
            }
        }

        public function load_company_tours(){
            $stmt=$this->connection->prepare("SELECT * FROM tour_plans WHERE company_id=:company_id"); 
            $stmt->bindValue(":company_id",$_SESSION['user_id']);

            $stmt->execute();

            if ($stmt->rowCount() > 0){
                $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
                $data=null;


//                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return array('status'=>1, 'message' => 'Tours loaded', 'data' => $rows);

            }
            else{
                return array('status'=>0, 'message' => 'No tours found');
            }
       }

        public function load_tours(){   
            $stmt=$this->connection->prepare("SELECT * FROM tour_plans"); 

            $stmt->execute();

            if ($stmt->rowCount() > 0){
                $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
                $data=null;


//                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return array('status'=>1, 'message' => 'Tours loaded', 'data' => $rows);

            }
            else{
                return array('status'=>1, 'message' => 'No records found', 'data'=>[]);
            }
       }

       public function load_tour_companies(){
            $stmt=$this->connection->prepare("SELECT * FROM users WHERE role_id=2"); 

            $stmt->execute();

            if ($stmt->rowCount() > 0){
                $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
                return array('status'=>1, 'message' => 'Tour companies loaded', 'data' => $rows);

            }
            else{
                return array('status'=>1, 'message' => 'No records found', 'data'=>[]);
            }
       }

        public function create_tour($params){
            $dirName = "../files/tour_plane/";
            if (!empty($params["mFile"]["name"])) {
                $mfileName = $params["mFile"]["name"];
                $mfileName = str_replace(" ", "_", strtolower($mfileName));
                move_uploaded_file($_FILES['mFile']['tmp_name'], $dirName . $mfileName);
            }
            $company_id=$_SESSION['user_id'];
            $stmt=$this->connection->prepare("INSERT into tour_plans (company_id, title, description, charges, destination, days, date, tp_night, tb_pickup, tb_drop, tb_stay, tb_accomodation, tb_km, tb_food, tb_image) VALUES (:company_id, :title, :description, :charges, :destination, :days, :date, :tp_night, :tb_pickup, :tb_drop, :tb_stay, :tb_accomodation, :tb_km, :tb_food, :tb_image)"); 
            $stmt->bindValue(":company_id",$company_id);
            $stmt->bindValue(":title",$params['title']);
            $stmt->bindValue(":description",$params['description']);
            $stmt->bindValue(":charges",$params['charges']);
            $stmt->bindValue(":destination",$params['destination']);
            $stmt->bindValue(":days",$params['days']);
            $stmt->bindValue(":date",$params['date']);
            $stmt->bindValue(":tp_night",$params['tp_night']);
            $stmt->bindValue(":tb_pickup",$params['tb_pickup']);
            $stmt->bindValue(":tb_drop",$params['tb_drop']);
            $stmt->bindValue(":tb_stay",$params['tb_stay']);
            $stmt->bindValue(":tb_accomodation",$params['tb_accomodation']);
            $stmt->bindValue(":tb_km",$params['tb_km']);
            $stmt->bindValue(":tb_food",$params['tb_food']);
            $stmt->bindValue(":tb_image",$params['tb_image']);

            $stmt->execute();

            if ($stmt){
                $id = $this->connection->lastInsertId();
                return array('status'=>1, 'message' => 'Tour plan created successfully!', 'user_id' => $id);
            }
            else{
                return array('status'=>0, 'message' => 'Error registeration');
            }
       }

       public function approve_tour($params){
            $stmt=$this->connection->prepare("UPDATE tour_plans SET approval=1 WHERE tp_id=:tp_id"); 
            $stmt->bindValue(":tp_id",$params['tp_id']);

            $stmt->execute();

            if ($stmt){
                return $this->load_tours();
                //return array('status'=>1, 'message' => 'Tour plan approved successfully!');
            }
            else{
                return array('status'=>0, 'message' => 'Error approving tour plan');
            }
       }

       public function search_destinations($params){
            $query="SELECT * FROM tour_plans WHERE
            destination LIKE '%".$params['search_string']."%'
            OR title LIKE '%".$params['search_string']."%'
            OR description LIKE '%".$params['search_string']."%'";

            $stmt=$this->connection->prepare($query); 
            $stmt->execute();

            if ($stmt->rowCount() > 0){
                $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
                $data=null;


//                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                return array('status'=>1, 'message' => 'Tours loaded', 'data' => $rows);

            }
            else{
                return array('status'=>0, 'message' => 'No tours found');
            }
       }


       private function checkRecord($tbl, $field, $val){
            $stmt=$this->connection->prepare("SELECT {$field} from {$tbl} WHERE {$field}=:val"); 
            $stmt->bindValue(":val", $val);
            $stmt->execute();
            if($stmt->rowCount() > 0){
                return true;
            }
            else{
                return false;
            }

       }
    }
?>