-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 28, 2023 at 07:36 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `emp`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedbacks`
--

DROP TABLE IF EXISTS `feedbacks`;
CREATE TABLE IF NOT EXISTS `feedbacks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `rating` double NOT NULL,
  `feedback_text` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tour_plans`
--

DROP TABLE IF EXISTS `tour_plans`;
CREATE TABLE IF NOT EXISTS `tour_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_id` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `description` varchar(256) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Upcoming',
  `approval` tinyint(4) NOT NULL DEFAULT '0',
  `charges` double NOT NULL,
  `destination` varchar(256) NOT NULL,
  `destination_lat` float NOT NULL DEFAULT '0',
  `destination_long` float NOT NULL DEFAULT '0',
  `distance` float NOT NULL DEFAULT '0',
  `attractions` varchar(256) NOT NULL DEFAULT '""',
  `days` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tour_plans`
--

INSERT INTO `tour_plans` (`id`, `company_id`, `title`, `description`, `status`, `approval`, `charges`, `destination`, `destination_lat`, `destination_long`, `distance`, `attractions`, `days`, `date`) VALUES
(5, 33, 'Murree Tour', 'There are many cultural attractions at this destination, you would love to explore more with variety of foods', 'Upcoming', 1, 5000, 'Murree, Pakistan', 0, 0, 0, '\"\"', 1, '2023-03-30'),
(6, 33, 'Naran Kaghan Tour', 'Naran Kaghan Valley is beautiful destination surrounded by blue lakes and high peaks. ', 'Upcoming', 1, 20000, 'Naran, Pakistan', 0, 0, 0, '\"\"', 1, '2023-04-08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `address` varchar(256) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `address`, `phone`, `email`, `password`) VALUES
(1, 1, 'admin', 'Lahore', '03244945105', 'email4saniya@gmail.com', 'admin'),
(35, 2, 'Shahbaz Ali', 'Lahore', '03004343163', 'email4abc@gmail.com', 'test123'),
(34, 2, 'Fizza', 'Lahore', '03004343163', 'email4fizza@gmail.com', 'aaaaaa'),
(33, 2, 'Shahbaz Ali', 'Lahore', '03004343163', 'email4huzaifa@gmail.com', 'test123'),
(32, 3, 'Shahbaz Ali', 'Lahore', '03004343163', 'email4shahbaz@gmail.com', 'test123');

-- --------------------------------------------------------

--
-- Table structure for table `user_roles`
--

DROP TABLE IF EXISTS `user_roles`;
CREATE TABLE IF NOT EXISTS `user_roles` (
  `id` int(11) NOT NULL,
  `role_name` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_roles`
--

INSERT INTO `user_roles` (`id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Company'),
(3, 'Visitor');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
